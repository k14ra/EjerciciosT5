package edu.alonso.daw.metodosStringKiara;

import java.util.Scanner;

/**
 * 
 * @author Kiara
 *
 */
public class toLowerCase {
	/*El método toLowerCase() es un metodo que nos permite 
	 * pasar una cadena entera a letras minusculas.*/
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce una cadena y la devolveré en minúsculas: ");
		String cadena = sc.nextLine();
		
		System.out.println("Cadena original --> " + cadena);
		System.out.println("Cadena en minusculas --> " + cadena.toLowerCase());
//		System.out.println("Cadena en minusculas --> " + cadena.toUpperCase());
		
		/*Podemos hacer uso de este metodo a la hora de comparar cadenas
		 * y hacer uso de el para hacer validaciones y sea mas sencillo.*/
		
		System.out.println();
		
	}
}
