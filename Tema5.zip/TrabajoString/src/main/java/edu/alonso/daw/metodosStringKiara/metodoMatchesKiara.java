package edu.alonso.daw.metodosStringKiara;

import java.util.Scanner;

/**
 * Matches -- evalua si hay coincidencia con una EXPRESIÓN REGULAR
 * 
 * @author Kiara
 *
 */

// [0-9]    ---> 1 Dígito numérico (1,1)
// [0-9]?   ---> o existe o existe 1 dígito numérico (0,1)
// [0-9]+   ---> N dígitos numéricos, como mínimo 1 (1,n)
// [0-9]*   ---> N dígitos numéricos, como mínimo 0  (0,n)
// [0-9]{4} ---> 4 dígitos numéricos

public class metodoMatchesKiara {

	private final static String dni = "70223778C"; // "x23032765d"

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un numero entre 1 y 1000 ");
		String entrada = sc.nextLine();
		sc.close();

		if (entrada.matches("[0-9]+")) {
			// Aqui empleo tambien el metodo valueOf, el cual
			// devuelve el valor primitivo de un objeto String como un tipo de dato cadena.
			int num = Integer.valueOf(entrada);
			if ((num >= 1) && (num <= 1000)) {
				System.out.println("OK");
			} else {
				System.out.println("Numero que no esta en el rango");
			}
		} else {
			System.out.println("Numero NO valido");
		}

		// OTRO EJEMPLO:
		System.out.println("Validacion del DNI " + dni + " --> " + dniValidator(dni));

	}

	private static boolean dniValidator(String dni) {
		boolean bDNI;
		// if (dni.toUpperCase().matches("[X]?[0-9]{8}[A-Z]"))
		if (dni.matches("[Xx]?[0-9]{8}[A-Za-z]")) {
			bDNI = true;
		} else {
			bDNI = false;
		}
		return bDNI;
	}

}
