package edu.alonso.daw.metodosStringKiara;

public class compareToIgnoreCase {

}
